from models.anggota import *
    # def __init__(self, anggota_id, nama, email, telephone, status_anggota):
    #     self.anggota_id = anggota_id
    #     self.nama = nama
    #     self.email = email
    #     self.telephone = telephone
    #     self.status_anggota = status_anggota
def test_anggota_model():
    IDAnggota = 100
    nama = "Kera Sakti Chan"
    email = "rainbowpowerpuff@gmail.com"
    telephone = "085261138911"
    status = 1

    anggota = Anggota(IDAnggota,nama,email,telephone,status)

    assert anggota.anggota_id == IDAnggota
    assert anggota.nama == nama
    assert anggota.email == email
    assert anggota.telephone == telephone
    assert anggota.status_anggota == status